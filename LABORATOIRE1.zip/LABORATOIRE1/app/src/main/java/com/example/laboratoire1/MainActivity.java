package com.example.laboratoire1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


        public void onClickChck(View view) {
            CheckBox checkBox = (CheckBox) findViewById(R.id.checkBox);
            EditText password = (EditText) findViewById(R.id.password);
            if (checkBox.isChecked()) {
                password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            } else {
                password.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        }

    public boolean isValidPassword(final String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%&()\\[\\]{}_=<>+\\-!?*/|:;.,‘\"~^]).{10,}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public void onClickButton(View view){
        Button button = (Button) findViewById(R.id.buttonValider);
        TextView err = (TextView) findViewById(R.id.err);
        EditText password = (EditText) findViewById(R.id.password);
        int blue = ContextCompat.getColor(this, R.color.blue);
        int red = ContextCompat.getColor(this, R.color.red);
        String valide = getResources().getString(R.string.msgValide);
        String invalide = getResources().getString(R.string.msgInvalide);

        if (isValidPassword(password.getText().toString().trim())){
            err.setText(valide);
            err.setTextColor(blue);
        }else {
            err.setText(invalide);
            err.setTextColor(red);
        }
    }
}
